//
//  BViewController.swift
//  ImagepickerTask
//
//  Created by vijay on 03/02/19.
//  Copyright © 2019 vijay. All rights reserved.
//

import UIKit
import CoreImage

class BViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    //MARK:- IBOutlets
    var img : UIImage?
    var CIFilterNames = [
        "CIPhotoEffectChrome","CIPhotoEffectFade","CIVignette","CIVignetteEffect",
        "CIPhotoEffectInstant","CIPhotoEffectNoir","CIPageCurlWithShadowTransition",
        "CIPhotoEffectTonal","CIPhotoEffectTransfer",
        "CISepiaTone","CIColorClamp","CIBoxBlur","CIDiscBlur",
        "CIGaussianBlur","CIMaskedVariableBlur",
        "CIZoomBlur","CIPhotoEffectProcess","CIPhotoEffectTransfer","CISepiaTone",
        "CIPhotoEffectFade","CIPhotoEffectInstant",
        "CIPhotoEffectMono","CIPhotoEffectNoir",
        "CIPhotoEffectProcess","CIBumpDistortion","CIBumpDistortionLinear",
        "CICircularWrap","CIDisplacementDistortion",
        "CIGlassDistortion","CIGlassLozenge",
        "CIHoleDistortion","CIPinchDistortion",
        "CIStretchCrop","CITorusLensDistortion",
        "CITwirlDistortion","CIVortexDistortion",
        "CIPerspectiveTransform","CIPerspectiveTransformWithExtent",
        "CICircularScreen","CICMYKHalftone","CIDotScreen","CIHatchedScreen",
        "CILineScreen","CISharpenLuminance","CIUnsharpMask","CIBloom",
        "CICrystallize","CIDepthOfField","CIEdges",
        "CIEdgeWork","CIGloom","CIHeightFieldFromMask","CIHexagonalPixellate",
        "CIHighlightShadowAdjust","CILineOverlay","CIPixellate",
        "CIPointillize","CISpotColor","CISpotLight"
    ]
    let filterButton = UIButton(type: .custom)
    @IBOutlet var imgvw2 : UIImageView!
    @IBOutlet var scrvw : UIScrollView!
    var lastRotation: CGFloat = 0
    @IBOutlet var backgroundView : UIView!
    @IBOutlet weak var viewBottomConstraints: NSLayoutConstraint!
    @IBOutlet var animatedView : UIView!
    @IBOutlet var animatingScrlvw : UIScrollView!
    var aCIImage = CIImage();
    var contrastFilter: CIFilter!;
    var brightnessFilter: CIFilter!;
    var context = CIContext();
    var outputImage = CIImage();
    var newUIImage = UIImage();
    @IBOutlet var brightnesssldr : UISlider!
    @IBOutlet var contrastslider : UISlider!
    @IBOutlet var saturationSldr : UISlider!
    @IBOutlet var texthere : UILabel!
    @IBOutlet var txtfldfortxt : UITextField!
    @IBOutlet var textbtn : UIButton!
    @IBOutlet var donebtn : UIButton!
    @IBOutlet var effectsbtn : UIButton!
    @IBOutlet var contrastbtn : UIButton!
    @IBOutlet var textenterbtn : UIButton!
    @IBOutlet var brightnessbtn : UIButton!
    @IBOutlet var stickerbtn : UIButton!
    @IBOutlet var imgvw1 : UIImageView!
    @IBOutlet var picker : UIPickerView!

    //MARK:- View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        callingGestures()
        general()
    }
    
    //MARK:- Additional Functions
    func general()
    {
        scrvw.showsHorizontalScrollIndicator = false
        imgvw2.image = img
        scrvw.contentSize = CGSize(width: 600, height: 75)
        brtcntrst()
        imgvw1.addSubview(texthere)
        imgvw2.isHidden = true
        imgvw1.image = img
    }

    func callingGestures(){
        imgvw1.clipsToBounds = true
        backgroundView.clipsToBounds = true
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(draggedView(_:)))
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchedView(sender:)))
        let rotate = UIRotationGestureRecognizer(target: self, action: #selector(rotateActionForImage(sender:)))
        let panGesture2 = UIPanGestureRecognizer(target: self, action: #selector(draggedView2(_:)))
        let pinchGesture2 = UIPinchGestureRecognizer(target: self, action: #selector(pinchedView2(sender:)))
        let rotate2 = UIRotationGestureRecognizer(target: self, action: #selector(rotateActionForImage2(sender:)))
        imgvw1.addGestureRecognizer(panGesture)
        imgvw1.addGestureRecognizer(pinchGesture)
        imgvw1.addGestureRecognizer(rotate)
        texthere.addGestureRecognizer(panGesture2)
        texthere.addGestureRecognizer(pinchGesture2)
        texthere.addGestureRecognizer(rotate2)
    }
    
    func scrollCreation() {
        var xCoord: CGFloat = 5
        let yCoord: CGFloat = 5
        let buttonWidth:CGFloat = 50.0
        let buttonHeight: CGFloat = 50.0
        let gapBetweenButtons: CGFloat = 10
        
        for i in 0..<CIFilterNames.count{
            let filterButton = UIButton(type: .custom)
            filterButton.frame = CGRect(x: xCoord, y: yCoord, width: buttonWidth, height: buttonHeight)
            filterButton.tag = i
            filterButton.addTarget(self, action:#selector(buttonTapped), for: .touchUpInside)
            filterButton.layer.cornerRadius = filterButton.frame.size.width/2
            filterButton.clipsToBounds = true
            xCoord +=  buttonWidth + gapBetweenButtons
            let ciContext = CIContext(options: nil)
            let coreImage = CIImage(image: imgvw2.image!)
            let filter = CIFilter(name: "\(CIFilterNames[i])" )
            filter!.setDefaults()
            filter!.setValue(coreImage, forKey: kCIInputImageKey)
            print(filter as Any)
            let filteredImageData = filter!.value(forKey: kCIOutputImageKey) as! CIImage
            let filteredImageRef = ciContext.createCGImage(filteredImageData, from: filteredImageData.extent)
            let imageForButton = UIImage(cgImage: filteredImageRef!);
            filterButton.setBackgroundImage(imageForButton, for: .normal)
            animatingScrlvw.addSubview(filterButton)
            animatingScrlvw.contentSize = CGSize(width:buttonWidth*CGFloat(CIFilterNames.count+(CIFilterNames.count/4)) , height: 50 )
        }
    }
    
    func hideanimation(){
        UIView.animate(withDuration: 0.5, animations: {
            self.viewBottomConstraints.constant = -250
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    func brtcntrst(){
        let aUIImage = imgvw2.image;
        let aCGImage = aUIImage?.cgImage;
        aCIImage = CIImage(cgImage: aCGImage!)
        context = CIContext(options: nil);
        contrastFilter = CIFilter(name: "CIColorControls");
        contrastFilter.setValue(aCIImage, forKey: "inputImage")
        brightnessFilter = CIFilter(name: "CIColorControls");
        brightnessFilter.setValue(aCIImage, forKey: "inputImage")
    }
    //MARK:- PickerView Related Functions
    let colors = [UIColor.red,UIColor.green,UIColor.blue,UIColor.black,UIColor.brown,
                  UIColor.cyan,UIColor.clear,UIColor.darkGray,UIColor.darkText,
                  UIColor.gray,UIColor.lightGray,UIColor.lightText,UIColor.magenta,
                  UIColor.orange,UIColor.purple,UIColor.white,UIColor.yellow]
    let colorsNames = ["Red","Green","Blue","Black","Brown","Cyan","Clear","D-Gray",
                       "D-Text","Gray","L-Gray","L-Text","Magenta","Orange","Purple",
                       "White","Yellow"]
    let styles = ["AcademyEngravedLetPlain",
        "AlNile","AlNile-Bold",
        "AmericanTypewriter","AmericanTypewriter-Bold",
        "AmericanTypewriter-Condensed","AmericanTypewriter-CondensedBold",
        "AmericanTypewriter-CondensedLight",
        "AmericanTypewriter-Light","AmericanTypewriter-Semibold",
        "AppleColorEmoji",
        "AppleSDGothicNeo-Bold","AppleSDGothicNeo-Light","AppleSDGothicNeo-Medium",
        "AppleSDGothicNeo-Regular",
        "AppleSDGothicNeo-SemiBold","AppleSDGothicNeo-Thin","AppleSDGothicNeo-UltraLight",
        "Arial-BoldItalicMT","Arial-BoldMT","Arial-ItalicMT","ArialMT",
        "ArialHebrew","ArialHebrew-Bold","ArialHebrew-Light",
        "ArialRoundedMTBold",
        "Avenir-Black","Avenir-BlackOblique","Avenir-Book","Avenir-BookOblique",
        "Avenir-Heavy","Avenir-HeavyOblique","Avenir-Light",
        "Avenir-LightOblique","Avenir-Medium","Avenir-MediumOblique",
        "Avenir-Oblique","Avenir-Roman",
        "AvenirNext-Bold","AvenirNext-BoldItalic","AvenirNext-DemiBold",
        "AvenirNext-DemiBoldItalic","AvenirNext-Heavy","AvenirNext-HeavyItalic",
        "AvenirNext-Italic","AvenirNext-Medium","AvenirNext-MediumItalic",
        "AvenirNext-Regular","AvenirNext-UltraLight","AvenirNext-UltraLightItalic",
        "AvenirNextCondensed-Bold",
        /*AvenirNextCondensed-BoldItalic
        AvenirNextCondensed-DemiBold
        AvenirNextCondensed-DemiBoldItalic
        AvenirNextCondensed-Heavy
        AvenirNextCondensed-HeavyItalic
        AvenirNextCondensed-Italic
        AvenirNextCondensed-Medium
        AvenirNextCondensed-MediumItalic
        AvenirNextCondensed-Regular
        AvenirNextCondensed-UltraLight
        AvenirNextCondensed-UltraLightItalic
        Baskerville
        Baskerville-Bold
        Baskerville-BoldItalic
        Baskerville-Italic
        Baskerville-SemiBold
        Baskerville-SemiBoldItalic
        ---------------------
        *** Bodoni 72 ***
        BodoniSvtyTwoITCTT-Bold
        BodoniSvtyTwoITCTT-Book
        BodoniSvtyTwoITCTT-BookIta
        ---------------------
        *** Bodoni 72 Oldstyle ***
        BodoniSvtyTwoOSITCTT-Bold
        BodoniSvtyTwoOSITCTT-Book
        BodoniSvtyTwoOSITCTT-BookIt
        ---------------------
        *** Bodoni 72 Smallcaps ***
        BodoniSvtyTwoSCITCTT-Book
        ---------------------
        *** Bodoni Ornaments ***
        BodoniOrnamentsITCTT
        ---------------------
        *** Bradley Hand ***
        BradleyHandITCTT-Bold
        ---------------------
        *** Chalkboard SE ***
        ChalkboardSE-Bold
        ChalkboardSE-Light
        ChalkboardSE-Regular
        ---------------------
        *** Chalkduster ***
        Chalkduster
        ---------------------
        *** Charter ***
        Charter-Black
        Charter-BlackItalic
        Charter-Bold
        Charter-BoldItalic
        Charter-Italic
        Charter-Roman
        ---------------------
        *** Cochin ***
        Cochin
        Cochin-Bold
        Cochin-BoldItalic
        Cochin-Italic
        ---------------------
        *** Copperplate ***
        Copperplate
        Copperplate-Bold
        Copperplate-Light
        ---------------------
        *** Courier ***
        Courier
        Courier-Bold
        Courier-BoldOblique
        Courier-Oblique
        ---------------------
        *** Courier New ***
        CourierNewPS-BoldItalicMT
        CourierNewPS-BoldMT
        CourierNewPS-ItalicMT
        CourierNewPSMT
        ---------------------
        *** DIN Alternate ***
        DINAlternate-Bold
        ---------------------
        *** DIN Condensed ***
        DINCondensed-Bold
        ---------------------
        *** Damascus ***
        Damascus
        DamascusBold
        DamascusLight
        DamascusMedium
        DamascusSemiBold
        ---------------------
        *** Devanagari Sangam MN ***
        DevanagariSangamMN
        DevanagariSangamMN-Bold
        ---------------------
        *** Didot ***
        Didot
        Didot-Bold
        Didot-Italic
        ---------------------
        *** Euphemia UCAS ***
        EuphemiaUCAS
        EuphemiaUCAS-Bold
        EuphemiaUCAS-Italic
        ---------------------
        *** Farah ***
        Farah
        ---------------------
        *** Futura ***
        Futura-Bold
        Futura-CondensedExtraBold
        Futura-CondensedMedium
        Futura-Medium
        Futura-MediumItalic
        ---------------------
        *** Geeza Pro ***
        GeezaPro
        GeezaPro-Bold
        ---------------------
        *** Georgia ***
        Georgia
        Georgia-Bold
        Georgia-BoldItalic
        Georgia-Italic
        ---------------------
        *** Gill Sans ***
        GillSans
        GillSans-Bold
        GillSans-BoldItalic
        GillSans-Italic
        GillSans-Light
        GillSans-LightItalic
        GillSans-SemiBold
        GillSans-SemiBoldItalic
        GillSans-UltraBold
        ---------------------
        *** Gujarati Sangam MN ***
        GujaratiSangamMN
        GujaratiSangamMN-Bold
        ---------------------
        *** Gurmukhi MN ***
        GurmukhiMN
        GurmukhiMN-Bold
        ---------------------
        *** Heiti SC ***
        ---------------------
        *** Heiti TC ***
        ---------------------
        *** Helvetica ***
        Helvetica
        Helvetica-Bold
        Helvetica-BoldOblique
        Helvetica-Light
        Helvetica-LightOblique
        Helvetica-Oblique
        ---------------------
        *** Helvetica Neue ***
        HelveticaNeue
        HelveticaNeue-Bold
        HelveticaNeue-BoldItalic
        HelveticaNeue-CondensedBlack
        HelveticaNeue-CondensedBold
        HelveticaNeue-Italic
        HelveticaNeue-Light
        HelveticaNeue-LightItalic
        HelveticaNeue-Medium
        HelveticaNeue-MediumItalic
        HelveticaNeue-Thin
        HelveticaNeue-ThinItalic
        HelveticaNeue-UltraLight
        HelveticaNeue-UltraLightItalic
        ---------------------
        *** Hiragino Maru Gothic ProN ***
        HiraMaruProN-W4
        ---------------------
        *** Hiragino Mincho ProN ***
        HiraMinProN-W3
        HiraMinProN-W6
        ---------------------
        *** Hiragino Sans ***
        HiraginoSans-W3
        HiraginoSans-W6
        ---------------------
        *** Hoefler Text ***
        HoeflerText-Black
        HoeflerText-BlackItalic
        HoeflerText-Italic
        HoeflerText-Regular
        ---------------------
        *** Kailasa ***
        Kailasa
        Kailasa-Bold
        ---------------------
        *** Kannada Sangam MN ***
        KannadaSangamMN
        KannadaSangamMN-Bold
        ---------------------
        *** Kefa ***
        Kefa-Regular
        ---------------------
        *** Khmer Sangam MN ***
        KhmerSangamMN
        ---------------------
        *** Kohinoor Bangla ***
        KohinoorBangla-Light
        KohinoorBangla-Regular
        KohinoorBangla-Semibold
        ---------------------
        *** Kohinoor Devanagari ***
        KohinoorDevanagari-Light
        KohinoorDevanagari-Regular
        KohinoorDevanagari-Semibold
        ---------------------
        *** Kohinoor Telugu ***
        KohinoorTelugu-Light
        KohinoorTelugu-Medium
        KohinoorTelugu-Regular
        ---------------------
        *** Lao Sangam MN ***
        LaoSangamMN
        ---------------------
        *** Malayalam Sangam MN ***
        MalayalamSangamMN
        MalayalamSangamMN-Bold
        ---------------------
        *** Marker Felt ***
        MarkerFelt-Thin
        MarkerFelt-Wide
        ---------------------
        *** Menlo ***
        Menlo-Bold
        Menlo-BoldItalic
        Menlo-Italic
        Menlo-Regular
        ---------------------
        *** Mishafi ***
        DiwanMishafi
        ---------------------
        *** Myanmar Sangam MN ***
        MyanmarSangamMN
        MyanmarSangamMN-Bold
        ---------------------
        *** Noteworthy ***
        Noteworthy-Bold
        Noteworthy-Light
        ---------------------
        *** Noto Nastaliq Urdu ***
        NotoNastaliqUrdu
        ---------------------
        *** Noto Sans Chakma ***
        NotoSansChakma-Regular
        ---------------------
        *** Optima ***
        Optima-Bold
        Optima-BoldItalic
        Optima-ExtraBlack
        Optima-Italic
        Optima-Regular
        ---------------------
        *** Oriya Sangam MN ***
        OriyaSangamMN
        OriyaSangamMN-Bold
        ---------------------
        *** Palatino ***
        Palatino-Bold
        Palatino-BoldItalic
        Palatino-Italic
        Palatino-Roman
        ---------------------
        *** Papyrus ***
        Papyrus
        Papyrus-Condensed
        ---------------------
        *** Party LET ***
        PartyLetPlain
        ---------------------
        *** PingFang HK ***
        PingFangHK-Light
        PingFangHK-Medium
        PingFangHK-Regular
        PingFangHK-Semibold
        PingFangHK-Thin
        PingFangHK-Ultralight
        ---------------------
        *** PingFang SC ***
        PingFangSC-Light
        PingFangSC-Medium
        PingFangSC-Regular
        PingFangSC-Semibold
        PingFangSC-Thin
        PingFangSC-Ultralight*/
        "PingFangTC-Light","PingFangTC-Medium","PingFangTC-Regular",
        "PingFangTC-Semibold","PingFangTC-Thin","PingFangTC-Ultralight",
        "Rockwell-Bold","Rockwell-BoldItalic","Rockwell-Italic","Rockwell-Regular",
        "SavoyeLetPlain","SinhalaSangamMN","SinhalaSangamMN-Bold",
        "SnellRoundhand","SnellRoundhand-Black","SnellRoundhand-Bold","Symbol",
        "TamilSangamMN","TamilSangamMN-Bold",
        "Thonburi","Thonburi-Bold","Thonburi-Light",
        "TimesNewRomanPS-BoldItalicMT",
        "TimesNewRomanPS-BoldMT","TimesNewRomanPS-ItalicMT","TimesNewRomanPSMT",
        "Trebuchet-BoldItalic","TrebuchetMS","TrebuchetMS-Bold","TrebuchetMS-Italic",
        "Verdana","Verdana-Bold","Verdana-BoldItalic","Verdana-Italic",
        "ZapfDingbatsITC","Zapfino"
        ]
    let fontSize = [1,2,3,4,5,6,7,8,9,10,12,14,16,18,20,25,30,40]
    let fontSizestring = ["1","2","3","4","5","6","7","8","9","10","12","14","16","18","20","25","30","40"]
    var stylename = ""
    var size = 20
    var color = UIColor.black
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return colors.count
        }else if component == 1{
            return styles.count
        }else if component == 2{
            return fontSize.count
        }
        return 0
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return colorsNames[row]
        }else if component == 1{
            let hue = CGFloat(row)/CGFloat(styles.count)
            picker.backgroundColor = UIColor(hue: hue, saturation: 1.0, brightness: 1.0, alpha: 1.0)
            return styles[row]
        }else if component == 2{
            return fontSizestring[row]
        }
        return "Nothing"
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0{
            color = colors[row]
            texthere.textColor = color
            texthere.font = UIFont(name: stylename, size: CGFloat(size))
        }else if component == 1{
            stylename = styles[row]
            texthere.textColor = color
            texthere.font = UIFont(name: stylename, size: CGFloat(size))
        }else if component == 2{
            size = fontSize[row]
            texthere.textColor = color
            texthere.font = UIFont(name: stylename, size: CGFloat(size))
        }
    }
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        if component == 0{
            return NSAttributedString(string: colorsNames[row], attributes: [NSAttributedString.Key.foregroundColor: colors[row]])
        }else if component == 1{
            return NSAttributedString(string: styles[row], attributes: [NSAttributedString.Key.font: UIFont(name: styles[row], size: 20)!])
        }else if component == 2{
            return NSAttributedString(string: fontSizestring[row])
        }
        return NSAttributedString(string: "Nothing")
        
    }
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        let w = picker.frame.size.width
        if component == 0{
            return w/3.2
        }else if component == 1{
            return w/2
        }else if component == 2{
            return w/8.8
        }
        return 100
    }
    
    //MARK:- Gesture Actions
    @objc func buttonTapped(sender:UIButton){
        let i = sender as UIButton
        let i2 = i.tag
        print(CIFilterNames[i2])
        img = i.backgroundImage(for: UIControl.State.normal)
        imgvw1.image = img
        
    }
    
    @objc func pinchedView(sender:UIPinchGestureRecognizer){
        if let view = sender.view {
            view.transform = view.transform.scaledBy(x: sender.scale, y: sender.scale)
            sender.scale = 1
        }
    }
    
    @objc  func draggedView(_ panGesture:UIPanGestureRecognizer){
        let translation = panGesture.translation(in: view)
        panGesture.setTranslation(CGPoint.zero, in: view)
        let imgView = panGesture.view
        imgView?.center = CGPoint(x: (imgView?.center.x)!+translation.x, y: (imgView?.center.y)!+translation.y)
        imgView?.isMultipleTouchEnabled = true
        imgView?.isUserInteractionEnabled = true
    }

    @objc func rotateActionForImage(sender:UIRotationGestureRecognizer){
        let viewDrag = sender.view
        viewDrag?.transform=(viewDrag?.transform.rotated(by:sender.rotation))!
        sender.rotation=0
    }
    @objc func pinchedView2(sender:UIPinchGestureRecognizer){
        if let view = sender.view {
            view.transform = view.transform.scaledBy(x: sender.scale, y: sender.scale)
            sender.scale = 1
        }
    }
    
    @objc  func draggedView2(_ panGesture:UIPanGestureRecognizer){
        let translation = panGesture.translation(in: view)
        panGesture.setTranslation(CGPoint.zero, in: view)
        let imgView = panGesture.view
        imgView?.center = CGPoint(x: (imgView?.center.x)!+translation.x, y: (imgView?.center.y)!+translation.y)
        imgView?.isMultipleTouchEnabled = true
        imgView?.isUserInteractionEnabled = true
    }
    
    @objc func rotateActionForImage2(sender:UIRotationGestureRecognizer){
        let viewDrag = sender.view
        viewDrag?.transform=(viewDrag?.transform.rotated(by:sender.rotation))!
        sender.rotation=0
    }
    //MARK:- Slider Actions
    func sliderContrastValueChanged(sender: UISlider) {
        brtcntrst()
        contrastFilter.setValue(NSNumber(value: sender.value), forKey: "inputContrast")
        outputImage = contrastFilter.outputImage!;
        let cgimg = context.createCGImage(outputImage, from: outputImage.extent)
        newUIImage = UIImage(cgImage: cgimg!)
        imgvw1.image = newUIImage;
        print(contrastslider.value)
    }
    
    func sliderValueChanged(sender: UISlider) {
        brtcntrst()
        brightnessFilter.setValue(NSNumber(value: sender.value), forKey: "inputBrightness");
        outputImage = brightnessFilter.outputImage!;
        let imageRef = context.createCGImage(outputImage, from: outputImage.extent)
        newUIImage = UIImage(cgImage: imageRef!)
        imgvw1.image = newUIImage;
        print(brightnesssldr.value)
    }
    @IBAction func saturation(){
        donebtn.isHidden = false
        let ciimage = CIImage.init(cgImage: imgvw2.image!.cgImage!)
        let filter = CIFilter.init(name: "CIColorControls")
        filter?.setValue(ciimage, forKey: kCIInputImageKey)
        filter?.setValue(saturationSldr.value, forKey: kCIInputSaturationKey)
        let result = filter?.value(forKey: kCIOutputImageKey) as! CIImage
        let cgimage = CIContext.init(options: nil).createCGImage(result, from: result.extent)
        let image = UIImage.init(cgImage: cgimage!)
        imgvw1.image = image
        picker.isHidden = true
    }
    
    //MARK:- Button Actions
    @IBAction func Effects()
    {
        imgvw1.image = imgvw2.image
        texthere.isHidden = true
        txtfldfortxt.isHidden = true
        textbtn.isHidden = true
        picker.isHidden = true
        contrastslider.isHidden = true
        brightnesssldr.isHidden = true
        donebtn.isHidden = false
        saturationSldr.isHidden = true
        scrollCreation()
        UIView.animate(withDuration: 0.5, animations:
            {
            self.viewBottomConstraints.constant = 5
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    @IBAction func close()
    {
        hideanimation()
    }
    
    @IBAction func done(){
        img = imgvw1.image
        imgvw2.image = img
        UIGraphicsBeginImageContext(self.backgroundView.bounds.size)
        self.backgroundView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let sourceImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        imgvw1.image = sourceImage
        imgvw2.image = sourceImage
        donebtn.isHidden = true
        txtfldfortxt.isHidden = true
        textbtn.isHidden = true
        contrastslider.isHidden = true
        brightnesssldr.isHidden = true
        saturationSldr.isHidden = true
        hideanimation()
        picker.isHidden = true
    }
    
    @IBAction func save()
    {
        UIGraphicsBeginImageContext(self.backgroundView.bounds.size)
        self.backgroundView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let sourceImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(sourceImage!, nil, nil, nil)
        let alertvw = UIAlertController(title: "Effects World", message: "Your image has been saved to Photo Library", preferredStyle: .alert)
        alertvw.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alertvw, animated: true, completion: nil)
    }
    
    @IBAction func brightness(){
        imgvw1.image = imgvw2.image
        hideanimation()
        texthere.isHidden = true
        txtfldfortxt.isHidden = true
        textbtn.isHidden = true
        contrastslider.isHidden = true
        donebtn.isHidden = false
        brightnesssldr.isHidden = false
        saturationSldr.isHidden = true
        picker.isHidden = true
    }
    
    @IBAction func contrast(){
        imgvw1.image = imgvw2.image
        hideanimation()
        texthere.isHidden = true
        txtfldfortxt.isHidden = true
        textbtn.isHidden = true
        brightnesssldr.isHidden = true
        donebtn.isHidden = false
        contrastslider.isHidden = false
        saturationSldr.isHidden = true
        picker.isHidden = true
    }
    
    @IBAction func brtnssldr(){
        sliderValueChanged(sender: brightnesssldr)
    }
    
    @IBAction func cntrstsldr(){
        sliderContrastValueChanged(sender: contrastslider)
    }
    
    @IBAction func text(){
        imgvw1.image = imgvw2.image
        donebtn.isHidden = false
        texthere.isHidden = false
        txtfldfortxt.isHidden = false
        textbtn.isHidden = false
        picker.isHidden = false
        brightnesssldr.isHidden = true
        contrastslider.isHidden = true
        saturationSldr.isHidden = true
        hideanimation()
    }
    
    @IBAction func enter(){
        texthere.text = txtfldfortxt.text
    }

    @IBAction func saturationBtn(){
        imgvw1.image = imgvw2.image
        hideanimation()
        saturationSldr.isHidden = false
        texthere.isHidden = true
        txtfldfortxt.isHidden = true
        textbtn.isHidden = true
        brightnesssldr.isHidden = true
        contrastslider.isHidden = true
        picker.isHidden = true
    }
}
