//
//  PhotosCollectionViewCell.swift
//  EffectiveFilters
//
//  Created by vijay on 13/02/19.
//  Copyright © 2019 vijay. All rights reserved.
//

import UIKit

class PhotosCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageholder : UIImageView!
    
    
}
